# WattWise — Electricity Consumption Analysis System

> **College Capstone Project | Final Production Release**  
> Built with **Python**, **Flask**, **MySQL 8.0**, **Pandas**, **Chart.js**, and **ReportLab**.

---

## ⚡ Super Simple Setup for Friends & Teammates

Follow these 5 easy steps to run WattWise on your computer:

### Step 1: Install Dependencies
Open a terminal (PowerShell or Command Prompt) in this project folder and run:
```powershell
pip install -r requirements.txt
```

### Step 2: Configure Your MySQL Password
1. Copy `.env.example` and rename the copy to `.env`:
   ```powershell
   copy .env.example .env
   ```
2. Open `.env` in any text editor (VS Code, Notepad, etc.).
3. Enter your MySQL password next to `MYSQL_PASSWORD=`:
   ```ini
   MYSQL_HOST=localhost
   MYSQL_PORT=3306
   MYSQL_USER=root
   MYSQL_PASSWORD=your_actual_mysql_password
   MYSQL_DB=electricity_analysis
   DB_ENGINE=mysql
   ```
   *(Note: If your local MySQL root account has no password, leave it blank: `MYSQL_PASSWORD=`)*

### Step 3: Initialize Your Database (One Command)
Run the automated database setup script:
```powershell
python init_db.py
```
This single command automatically:
- Connects to your MySQL server.
- Creates the `electricity_analysis` database.
- Creates all required tables, relational constraints, and stored triggers.
- Seeds 10 realistic consumers, 12 meters, and 140 chronological readings (Jan 2025 – Feb 2026) across Andhra Pradesh.

### Step 4: Start the Application
```powershell
python run.py
```

### Step 5: Open in Your Web Browser
Open: [**http://127.0.0.1:5000**](http://127.0.0.1:5000)

You can verify that your MySQL database is active by visiting:  
[**http://127.0.0.1:5000/system**](http://127.0.0.1:5000/system)

---

## 🧪 Run Automated Tests

To run the complete automated test suite (24 unit, calculation, and route tests):
```powershell
pytest electricity_consumption_analysis/tests -v
```

---

## 🏛️ System Features
- **Dashboard Overview:** KPI cards, month-over-month trend (% change), interactive Chart.js line curve, high-usage alerts watch.
- **Consumer Management:** Residential, commercial, industrial, agricultural profiles with individual consumption histories.
- **Meter Hardware Registry:** Unique serial tracking, capacity rating, and consumer mapping.
- **Meter Reading Collection:** Monotonic sequence validation, baseline readings, and automatic period consumption calculation.
- **Tiered Tariff Billing:** Tiered slab calculation with fixed charges and electricity duty.
- **Environmental Carbon Footprint:** Grid emission factor estimation ($0.82\text{ kg CO}_2/\text{kWh}$).
- **Surveillance & Alerts:** High-consumption anomaly detection with configurable thresholds.
- **Reports Hub:** Machine-readable CSV export, ReportLab executive PDF generation, and printable audit sheets.
