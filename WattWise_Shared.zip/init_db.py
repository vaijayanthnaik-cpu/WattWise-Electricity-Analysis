"""
WattWise Database Initializer (Workspace Root Launcher)
"""
import os
import sys

PROJECT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "electricity_consumption_analysis")
if os.path.exists(PROJECT_DIR):
    os.chdir(PROJECT_DIR)
    sys.path.insert(0, PROJECT_DIR)

import init_db

if __name__ == "__main__":
    init_db.init_mysql(migrate_from_sqlite=True)
