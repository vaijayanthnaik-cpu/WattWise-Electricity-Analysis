"""
WattWise Demo Data Generator (Workspace Root Launcher)
"""
import os
import sys

PROJECT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "electricity_consumption_analysis")
if os.path.exists(PROJECT_DIR):
    os.chdir(PROJECT_DIR)
    sys.path.insert(0, PROJECT_DIR)

import seed_demo

if __name__ == "__main__":
    seed_demo.seed_database(clear_existing=False)
